document.addEventListener('DOMContentLoaded', () => {
  const pages = document.querySelectorAll('.page');
  const navLinks = document.querySelectorAll('.navbar a');

  // Function to show a particular page based on the navigation
  function showPage(id) {
    pages.forEach(page => {
      page.classList.remove('active');
      if (page.id === id) {
        page.classList.add('active');
      }
    });
  }

  // Navigation click event
  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const target = link.getAttribute('href').substring(1);
      showPage(target);
    });
  });

  // Default to Home page
  showPage('home');

  // Swipe functionality for touch devices
  let startX = 0;

  document.addEventListener('touchstart', (e) => {
    startX = e.touches[0].clientX;
  });

  document.addEventListener('touchmove', (e) => {
    const endX = e.touches[0].clientX;
    const diff = startX - endX;

    if (Math.abs(diff) > 50) {
      const activePage = document.querySelector('.page.active');
      let nextPage;

      if (diff > 0) {
        // Swipe left (go to the next page)
        nextPage = activePage.nextElementSibling;
      } else {
        // Swipe right (go to the previous page)
        nextPage = activePage.previousElementSibling;
      }

      if (nextPage && nextPage.classList.contains('page')) {
        showPage(nextPage.id);
      }

      startX = 0; // Reset the swipe start position
    }
  });
});
